#ifndef EXITCONTROL_H
#define EXITCONTROL_H

#include "compileprogcontrol.h"

class ExitControl {
public:
    void cleanUp();
};

#endif // EXITCONTROL_H
