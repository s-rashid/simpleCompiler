#ifndef SAVEFILECONTROL_H
#define SAVEFILECONTROL_H

#include "storage/storagemanager.h"

class SaveFileControl {
public:
    void saveProgram(QString&, QString&, QString&);
};

#endif // SAVEFILECONTROL_H
