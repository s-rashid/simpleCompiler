#ifndef RUNPROGCONTROL_H
#define RUNPROGCONTROL_H

#include "compileprogcontrol.h"

class RunProgramControl {
public:
    void launchProgram();
};

#endif // RUNPROGCONTROL_H
