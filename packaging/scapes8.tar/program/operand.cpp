#include "operand.h"

Operand::Operand() {}

Operand::~Operand() {}

