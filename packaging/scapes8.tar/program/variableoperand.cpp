#include "variableoperand.h"

VariableOperand::VariableOperand() : ValueOperand () {}
